package com.cg.twobeanclass;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;

public class MyBeanFactoryPP implements BeanFactoryPostProcessor {

	@Override
	public void postProcessBeanFactory(ConfigurableListableBeanFactory factory) throws BeansException {
		System.out.println("bean Factory Post Processor Implemented");
		Triangle triangle=factory.getBean("triangle",Triangle.class);
		triangle.getPointA().setX(100);
		triangle.getPointA().setY(100);
		triangle.getPointB().setX(100);
		triangle.getPointB().setY(100);
		triangle.getPointC().setX(100);
		triangle.getPointC().setY(100);
	}


}
