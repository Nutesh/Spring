package com.cg.twobeanclass;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
/**
 * 
 * @author nurathod
 *BeanNameAware is used to get the name of bean defined inside xml file
 *and setBeanName() will be automatically called by application context
 */
public class Circle implements BeanNameAware,BeanFactoryAware,InitializingBean,DisposableBean
,ApplicationContextAware{
private Point center;

public Point getCenter() {
	return center;
}

public void setCenter(Point center) {
	this.center = center;
}
public void draw() {
	
	System.out.println("Centre Point ("+center.getX()+","+center.getY()+")\n");
	System.out.println("Circle drawn!!\n");
}

@Override
public void setBeanName(String beanName) {
	System.out.println("Bean Name is : "+beanName+"\n");
	
}

@Override
public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
	System.out.println("setBeanFactory() Method called by the container\n");
	
}

@Override
public void afterPropertiesSet() throws Exception {
	System.out.println("After Properties set of InitialisingBean is being called\n");
	
}
/**
 * this method will not get executed automatically untill and unless
 * we define this in xml file inside init-method="startUp" 
 */
public void startUp() {
	System.out.println("My init method executed\n");
}
/**
 * destroy Method of Disposable 
 * this will called when application context will be closed
 * like in AppSpring.java context.registerShutdownHook()
 * will get called then container will get destroyed and only then this method will be called
 * @throws Exception
 */
@Override
public void destroy() throws Exception {
	System.out.println("Destroy method of disposable bean is executed\n");
	
}
/**
 * this custom draw method will get executed only when this will be defined inside xml file 
 * with tag as destroy-method
 * @throws Exception
 */
public void myDestroy() throws Exception {
	System.out.println("Custom destroy method is executed\n");
	
}
/**
 * this method will also be called automatically by the application context
 */
@Override
public void setApplicationContext(ApplicationContext arg0) throws BeansException {
	System.out.println("Set Application Context method of ApplicationContext is being executed\n");
	
}

}
