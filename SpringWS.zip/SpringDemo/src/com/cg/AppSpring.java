package com.cg;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class AppSpring {

	public static void main(String[] args) {
		/**
		 * BeanFcatory is interface which is container of bean
		 * finds spring.xml directly inside project folder
		 */
		//BeanFactory factory = new XmlBeanFactory(new FileSystemResource("spring.xml"));
		/**
		 * getBean method is used to give reference of bean class Triangle to 
		 */
		/*
		 * Triangle triangle = factory.getBean("triangle",Triangle.class);
		 * traingle.draw();
		 */
		/**
		 * using application context
		 * this finds file inside source folder not on project folder
		 */
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Triangle triangle = context.getBean("triangle",Triangle.class);
		triangle.draw();
	}

}
