package com.cg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.shapes.Circle;

public class App {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Circle circle = context.getBean("circle",Circle.class);
		circle.draw();
		System.out.println("Done");
		context.registerShutdownHook();
	}
}
