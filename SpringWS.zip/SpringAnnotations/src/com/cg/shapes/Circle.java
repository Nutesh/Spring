package com.cg.shapes;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

import com.cg.Point;
@Controller
/*@Service*/
/*
 * @Component("myBean")
 *//**
	 * above annotation will by default give id of bean as "center" for Center and
	 * same for every class also inside paranthesis we can specify name of bean
	 * class
	 * 
	 * @author nurathod
	 *
	 */
public class Circle {
	/**
	 * @Autowired
	 */
	/* @Resource(name = "point2") */
	@Autowired
	private Point center;

	public Point getCenter() {
		return center;
	}

	/**
	 * below annotation cannot be applied to property it must be applied to setter
	 * methods only
	 * 
	 * @param center
	 */
	/**
	 * can be used with setter too
	 * 
	 * @param center
	 */
	/**
	 * @Autowired
	 * @param center
	 */
	@Required
	public void setCenter(Point center) {
		this.center = center;
	}

	public void draw() {
		System.out.println("Center (" + center.getX() + "," + center.getY() + ")");
		System.out.println("Circle Drawn!!");
	}

	@PostConstruct
	public void myInit() {
		System.out.println("My Init method executed");
	}

	@PreDestroy
	public void myDestroy() {
		System.out.println("My destory method executed");
	}
}
