package com.cg.javabasedconfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.shapes.Circle;

public class App {

	public static void main(String[] args) {
		/*
		 * AbstractApplicationContext context = new
		 * ClassPathXmlApplicationContext("spring.xml");
		 */
		ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
		Circle1 circle = context.getBean("circle1",Circle1.class);
		circle.draw();
		System.out.println("Done");
		/* context.registerShutdownHook(); */
	}
}
