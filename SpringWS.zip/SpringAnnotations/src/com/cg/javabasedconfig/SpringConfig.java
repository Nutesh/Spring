package com.cg.javabasedconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
/**
 * if there are multiple packages where files needs to be wired then use basePackages
 * @author nurathod
 *
 */
@ComponentScan(basePackages = {"com.cg"})
/* @ComponentScan("com.cg") */
public class SpringConfig {
	@Bean
	public Point1 center() {
		Point1 point =new Point1();
		point.setX(20);
		point.setY(60);
		return point;
	}
	@Bean
	public Circle1 circle() {
		Circle1 circle = new Circle1();
		return circle;
	}

}
