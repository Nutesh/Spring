package com.cg;

import java.sql.Date;

public class Employee {
	/**
	 * 
	 * PropertyEditorSupport will be used when string data provided inside xml file 
	 * can't be converted into required datatype 
	 */
	private Date dob;

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}
	
}
