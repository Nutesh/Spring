package com.cg.shapes;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;


@Controller
/*@Service*/
/*
 * @Component("myBean")
 *//**
	 * above annotation will by default give id of bean as "center" for Center and
	 * same for every class also inside paranthesis we can specify name of bean
	 * class
	 * 
	 * @author nurathod
	 *
	 */
public class Circle {
	/**
	 * @Autowired
	 */
	/* @Resource(name = "point2") */
	@Autowired
	private Point center;
	
	@Autowired
	MessageSource messageSource;

	public Point getCenter() {
		return center;
	}

	/**
	 * below annotation cannot be applied to property it must be applied to setter
	 * methods only
	 * 
	 * @param center
	 */
	/**
	 * can be used with setter too
	 * 
	 * @param center
	 */
	/**
	 * @Autowired
	 * @param center
	 */
	@Required
	public void setCenter(Point center) {
		this.center = center;
	}

	public void draw() {
		
		String msg=messageSource.getMessage("greeting", null, "no key found", null);
		System.out.println(msg);
		String draw=messageSource.getMessage("circle.drawing", null, "key not found", null);
		//String points=messageSource.getMessage("circle.points", null, "key not found", null);
		String points=messageSource.getMessage("circle.points", new Object[] {center.getX(),center.getY()},"key not found",null);
		
		System.out.println(draw+"\n"+points);
		//System.out.println("Center (" + center.getX() + "," + center.getY() + ")");
		//System.out.println("Circle Drawn!!");
	}

	
}
