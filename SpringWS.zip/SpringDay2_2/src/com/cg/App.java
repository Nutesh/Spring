package com.cg;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.shapes.Circle;

public class App {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Circle circle = context.getBean("circle",Circle.class);
		circle.draw();
		MessageSource messageSource = (MessageSource) context.getBean("messageSource");
		Locale locale = new Locale("en","IN");
		String message = messageSource.getMessage("welcome.message", null, "no key found", locale);
		System.out.println(message);
		//context.registerShutdownHook();
	}
}
