package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;

public interface EmployeeDao {
	List<Employee> getAllEMployee() throws EmployeeException;

	List<Employee> deleteEmployee(int id) throws EmployeeException;
	
	List<Employee> addEmployee(Employee employee) throws EmployeeException;
}
