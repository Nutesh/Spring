package com.cg.emp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.cg.emp.dto.Employee;
import com.cg.emp.exception.EmployeeException;
import com.cg.emp.servoce.EmployeeService;

@Controller
public class EmployeeController {
	@Autowired
	EmployeeService employeeService;
	
	@RequestMapping("/greet")
	public String sayHello() {
		return "greet";
	}
	
	@RequestMapping("/")
	public ModelAndView showIndex() {
		try {
			List<Employee> employees = employeeService.getAllEMployee();
			ModelAndView modelAndView = new ModelAndView("index");
			modelAndView.addObject("employees", employees);
			return modelAndView;
		} catch (EmployeeException e) {
			ModelAndView modelAndView = new ModelAndView("error");
			modelAndView.addObject("error", e);
			return modelAndView;
		}
		
	}
	@RequestMapping("/delete")
	public ModelAndView deleteEmployee(@RequestParam("empId") int id) {
		try {
			List<Employee> employees = employeeService.deleteEmployee(id);
			System.out.println("=================");
			ModelAndView modelAndView = new ModelAndView("index");
			modelAndView.addObject("employees", employees);
			return modelAndView;
		} catch (EmployeeException e) {
			e.printStackTrace();
			ModelAndView modelAndView = new ModelAndView("error");
			modelAndView.addObject("error", e);
			return modelAndView;
		}
	}
	@RequestMapping("/addEmployee")
	public String showAddForm(Model model) {
		model.addAttribute("employee",new Employee());
		return "add";
	}
	
	@RequestMapping(value="/add" , method = RequestMethod.POST)
	public ModelAndView addEmployee(@Valid @ModelAttribute Employee employee,BindingResult result) {
		
		if(result.hasErrors()) {
			/**
			 * 
			 * ModelAndView mv = new ModelAndView("index");
			 * mv.addObject("employee",employee);
			 * return mv;
			 * 
			 * above code can be simplified as:-
			 */
			return new ModelAndView("add","employee",employee);
		}
		
		try {
			List<Employee> employees = employeeService.addEmployee(employee);
			ModelAndView modelAndView = new ModelAndView("index");
			modelAndView.addObject("employees", employees);
			return modelAndView;
		} catch (EmployeeException e) {
			e.printStackTrace();
			ModelAndView modelAndView = new ModelAndView("error");
			modelAndView.addObject("error", e);
			return modelAndView;
		}
	}
}
