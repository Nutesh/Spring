package com.cg.twobeanclass;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;



public class AppSpring {

	public static void main(String[] args) {
		/*
		 * ApplicationContext context = new
		 * ClassPathXmlApplicationContext("spring.xml"); Triangle triangle =
		 * context.getBean("triangle",Triangle.class); triangle.draw();
		 */
		/**
		 * AbstractApplicationContext is parent Interface for ApplicationContext
		 * only this interface have registerShutdownHook()
		 */
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		  TriangleCollection
		  triangleCollection=context.getBean("trianglecollection",TriangleCollection.
		  class); triangleCollection.draw();
		 
		/*
		 * Circle circle = context.getBean("circle",Circle.class); circle.draw();
		 */
		context.registerShutdownHook();

	}
}