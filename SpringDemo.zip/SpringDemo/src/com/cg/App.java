package com.cg;

public class App {

	public static void main(String[] args) {
		Triangle traingle = new Triangle();
		traingle.draw();

	}

}
